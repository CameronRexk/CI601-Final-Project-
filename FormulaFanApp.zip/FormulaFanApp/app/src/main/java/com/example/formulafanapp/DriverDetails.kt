package com.example.formulafanapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity


class DriverDetails : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_driver_details)

        // Attempt to load drivers
    }
    }
