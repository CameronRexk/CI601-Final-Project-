package com.example.formulafanapp

import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.maps.android.data.geojson.GeoJsonLayer
import com.google.maps.android.data.geojson.GeoJsonPoint
import com.google.maps.android.data.geojson.GeoJsonPointStyle
import org.json.JSONException
import java.io.IOException

class TrackLocations : AppCompatActivity(), OnMapReadyCallback, GoogleMap.InfoWindowAdapter, GoogleMap.OnInfoWindowClickListener {

    private lateinit var map: GoogleMap
    private lateinit var geoJsonLayer: GeoJsonLayer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_track_locations)

        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        map = googleMap

        val monaco = LatLng(43.7347, 7.4206)
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(monaco, 5f))

        try {
            geoJsonLayer = GeoJsonLayer(map, R.raw.f1locations, this)
            addGeoJsonLayerToMap(geoJsonLayer)
        } catch (e: IOException) {
            e.printStackTrace()
        } catch (e: JSONException) {
            e.printStackTrace()
        }

        map.setInfoWindowAdapter(this)
        map.setOnInfoWindowClickListener(this)
    }

    private fun addGeoJsonLayerToMap(layer: GeoJsonLayer) {
        for (feature in layer.features) {
            if (feature.geometry is GeoJsonPoint) {
                val pointStyle = GeoJsonPointStyle()
                pointStyle.title = feature.getProperty("name")
                pointStyle.snippet = feature.getProperty("location")
                feature.pointStyle = pointStyle
            }
        }
        layer.addLayerToMap()
    }

    override fun getInfoWindow(marker: Marker): View? {
        return null
    }

    override fun getInfoContents(marker: Marker): View {
        val infoView = layoutInflater.inflate(R.layout.custom_info_contents, null)
        val title: TextView = infoView.findViewById(R.id.title)
        val snippet: TextView = infoView.findViewById(R.id.location)
        val imageView: ImageView = infoView.findViewById(R.id.image)

        title.text = marker.title
        snippet.text = marker.snippet

        // Find the feature corresponding to this marker
        for (feature in geoJsonLayer.features) {
            if (feature.geometry is GeoJsonPoint) {
                val geoJsonPoint = feature.geometry as GeoJsonPoint
                if (geoJsonPoint.coordinates.latitude == marker.position.latitude &&
                    geoJsonPoint.coordinates.longitude == marker.position.longitude) {
                    val imageUrl = feature.getProperty("image")
                    // Use Glide to load the image
                    Glide.with(this).load(imageUrl).into(imageView)
                    break
                }
            }
        }
        return infoView
    }

    override fun onInfoWindowClick(marker: Marker) {
        // Handle the click event if needed
    }
}
