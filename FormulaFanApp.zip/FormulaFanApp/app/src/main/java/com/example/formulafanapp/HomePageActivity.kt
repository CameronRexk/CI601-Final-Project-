package com.example.formulafanapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class HomePageActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_page)


        findViewById<Button>(R.id.buttonDriverDetails).setOnClickListener {
            startActivity(Intent(this, DriverDetails::class.java))

        }

        findViewById<Button>(R.id.buttonLiveStandings).setOnClickListener {
            startActivity(Intent(this, LiveStandings::class.java))
        }

        findViewById<Button>(R.id.buttonSeasonCalendar).setOnClickListener {
            startActivity(Intent(this, SeasonCalendar::class.java))
        }

        findViewById<Button>(R.id.buttonTrackLocations).setOnClickListener {
            startActivity(Intent(this, TrackLocations::class.java))
        }
    }
}
