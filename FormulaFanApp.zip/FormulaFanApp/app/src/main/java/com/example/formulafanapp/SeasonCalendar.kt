package com.example.formulafanapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class SeasonCalendar : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_season_calendar)
    }
}
